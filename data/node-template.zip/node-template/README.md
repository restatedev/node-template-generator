# Restate Template for TypeScript / NodeJS

This project is a basic template for a Restate-based service in [TypeScript](https://www.typescriptlang.org/).
To use this template simply clone this repository.

The templated project uses the [Restate TypeScript SDK](https://github.com/restatedev/sdk-typescript)
and sets up dependencies, protobuf compilation, and other useful scripts.


# Developing a Restate Service

The basic steps of developing a Restate service are shown below. For a comprehensive guide,
please refer to the [Restate Docs](https://github.com/restatedev/documentation)
and the [TypeScript SDK Readme](https://github.com/restatedev/sdk-typescript/blob/main/README.md)

> &#x1F4DD; You need to have access to the private Restate npm packages. Please follow the instructions in the `restate-dist` Readme to set up access: https://github.com/restatedev/restate-dist


First, get all dependencies and build tools:
```
npm install
```

Next, adjust the 'proto' definitions. Then run:
```
npm run proto
```

Finally, implement your code. To build and run the code, do
```
npm run build
npm run app
```

Use `npm run app-dev` to start the application via `ts-node-dev` and reload automatically when files change.


# Using Development Mode (autoregister on changes)


# Contributing to this Template

When contributing changes to this template, please avoid checking in the following files:

  - `package-lock.json`
  - `proto/buf.lock`
  - `src/generated/**`

Those files are created by the install/build process. Some (or all) of those files
would typically be checked in by app developers that build on this template, but
should not be part of the template itself.

We currently avoid adding those files to `.gitignore`, so that we don't exclude them
for developers building on top of this template.

To make development of the template itself easier, you can add a local exclude for those
files by adding the lines below to the file `.git/info/exclude`.
You may need to create the file, if it does not exist, yet.

```
# in the projects created from this template, one would typically check those files in
# but we don't want to check them into the template
package-lock.json
proto/buf.lock
src/generated/proto/dev/restate/ext.ts
src/generated/proto/example.ts
src/generated/proto/google/protobuf/descriptor.ts
```
